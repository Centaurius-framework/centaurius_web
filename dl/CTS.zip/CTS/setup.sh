#!/bin/bash
clear
cat banner/install.txt
echo -e "\033[1;91m[\033[1;94m*\033[1;91m] Installing Dependence"
apt update && apt install ruby gem
